import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { apiClient, authService } from "@/App";
import { toast } from "sonner";
import { Send, CheckCircle, XCircle, Clock } from "lucide-react";

const FinancePortal = () => {
  const [pendingApprovals, setPendingApprovals] = useState([]);
  const [payments, setPayments] = useState([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [requestMessage, setRequestMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const user = authService.getUser();

  useEffect(() => {
    fetchFinanceData();
  }, []);

  const fetchFinanceData = async () => {
    try {
      const response = await apiClient.get("/payments");
      setPayments(response.data);
    } catch (error) {
      toast.error("Failed to fetch data");
    } finally {
      setLoading(false);
    }
  };

  const sendRequestToAdmin = async () => {
    try {
      await apiClient.post("/finance/request-approval", {
        message: requestMessage,
        request_type: "payment_approval"
      });
      toast.success("Request sent to admin for approval");
      setDialogOpen(false);
      setRequestMessage("");
    } catch (error) {
      toast.error("Failed to send request");
    }
  };

  const totalCollected = payments
    .filter(p => p.status === "completed")
    .reduce((sum, p) => sum + p.amount, 0);

  const pendingAmount = payments
    .filter(p => p.status === "pending")
    .reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Finance Portal</h2>
          <p className="text-slate-400 mt-1">Welcome, {user?.full_name}</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="request-approval-btn">
              <Send className="w-4 h-4 mr-2" />
              Request Admin Approval
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Send Request to Admin</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Textarea
                placeholder="Describe your request for admin approval..."
                rows={6}
                value={requestMessage}
                onChange={(e) => setRequestMessage(e.target.value)}
              />
              <Button onClick={sendRequestToAdmin} className="w-full">
                Send Request
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">Total Collected</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">KES {totalCollected.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">Pending</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">KES {pendingAmount.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">
              {payments.filter(p => {
                const paymentDate = new Date(p.created_at);
                const now = new Date();
                return paymentDate.getMonth() === now.getMonth();
              }).length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-600">Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{pendingApprovals.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Payments</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading...</div>
          ) : payments.length === 0 ? (
            <div className="text-center py-8 text-slate-500">No payments recorded</div>
          ) : (
            <div className="space-y-3">
              {payments.slice(0, 10).map((payment) => (
                <div
                  key={payment.id}
                  className="flex items-center justify-between p-4 border border-slate-200 rounded-lg"
                >
                  <div>
                    <p className="font-medium text-slate-900">KES {payment.amount}</p>
                    <p className="text-sm text-slate-500">
                      {payment.payment_method.replace('_', ' ').toUpperCase()} | {payment.payment_type}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-slate-500">
                      {new Date(payment.created_at).toLocaleDateString()}
                    </span>
                    <Badge
                      className={
                        payment.status === "completed"
                          ? "bg-green-100 text-green-800"
                          : payment.status === "pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-red-100 text-red-800"
                      }
                    >
                      {payment.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Admin Approval Requests</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12 text-slate-500">
            <Clock className="w-12 h-12 mx-auto mb-4 text-slate-400" />
            <p>No pending approval requests</p>
            <p className="text-sm mt-2">Use the button above to send requests to admin</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FinancePortal;
