import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { apiClient, authService } from "@/App";
import { Bell, FileText, CreditCard, Calendar, Download, Award, TrendingUp, User, BookOpen } from "lucide-react";
import jsPDF from "jspdf";
import { toast } from "sonner";

const StudentPortal = () => {
  const [studentData, setStudentData] = useState(null);
  const [announcements, setAnnouncements] = useState([]);
  const [feePayments, setFeePayments] = useState([]);
  const [results, setResults] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [loading, setLoading] = useState(true);
  const user = authService.getUser();

  useEffect(() => {
    fetchStudentData();
  }, []);

  const fetchStudentData = async () => {
    try {
      // Fetch student's specific data
      const [announcementsRes, paymentsRes, studentsRes] = await Promise.all([
        apiClient.get("/announcements").catch(() => ({ data: [] })),
        apiClient.get("/payments").catch(() => ({ data: [] })),
        apiClient.get("/students").catch(() => ({ data: [] }))
      ]);
      
      setAnnouncements(announcementsRes.data || []);
      setFeePayments(paymentsRes.data || []);
      
      // In real implementation, link parent to specific student
      // For now, using first student as example
      if (studentsRes.data && studentsRes.data.length > 0) {
        setStudentData(studentsRes.data[0]);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const generateFeeStatement = () => {
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text("Fee Payment Statement", 20, 20);
    doc.setFontSize(12);
    doc.text(`Student: ${studentData?.full_name || 'N/A'}`, 20, 35);
    doc.text(`Admission No: ${studentData?.admission_number || 'N/A'}`, 20, 45);
    doc.text(`Class: ${studentData?.class_name || studentData?.year_of_study || 'N/A'}`, 20, 55);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 20, 65);
    
    let y = 85;
    doc.setFontSize(14);
    doc.text("Payment History", 20, y);
    y += 10;
    
    doc.setFontSize(10);
    feePayments.forEach((payment, index) => {
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      doc.text(`${index + 1}. KES ${payment.amount} - ${payment.payment_method} - ${new Date(payment.created_at).toLocaleDateString()}`, 20, y);
      y += 8;
    });
    
    const totalPaid = feePayments.filter(p => p.status === 'completed').reduce((sum, p) => sum + p.amount, 0);
    y += 10;
    doc.setFontSize(12);
    doc.text(`Total Paid: KES ${totalPaid.toLocaleString()}`, 20, y);
    
    doc.save(`fee-statement-${Date.now()}.pdf`);
    toast.success("Fee statement downloaded");
  };

  const generateReportCard = () => {
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text("Student Progress Report", 20, 20);
    doc.setFontSize(12);
    doc.text(`Student: ${studentData?.full_name || 'N/A'}`, 20, 35);
    doc.text(`Class: ${studentData?.class_name || studentData?.year_of_study || 'N/A'}`, 20, 45);
    doc.text(`Academic Year: ${new Date().getFullYear()}`, 20, 55);
    doc.save(`progress-report-${Date.now()}.pdf`);
    toast.success("Progress report downloaded");
  };

  const totalPaid = feePayments.filter(p => p.status === 'completed').reduce((sum, p) => sum + p.amount, 0);
  const pendingFees = feePayments.filter(p => p.status === 'pending').reduce((sum, p) => sum + p.amount, 0);
  const attendanceRate = 95; // Calculate from actual data

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600/20 via-indigo-600/20 to-purple-700/20 border border-blue-500/20 rounded-2xl p-8 shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-4xl font-bold mb-2 text-white">Student & Parent Portal</h2>
            <p className="text-blue-300/70 text-lg mb-4">Welcome, {user?.full_name}</p>
            {studentData && (
              <div className="flex gap-3 flex-wrap">
                <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
                  <User className="w-4 h-4 mr-2" />
                  {studentData.full_name}
                </Badge>
                <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
                  <BookOpen className="w-4 h-4 mr-2" />
                  {studentData.class_name || studentData.year_of_study}
                </Badge>
                <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
                  {studentData.admission_number}
                </Badge>
              </div>
            )}
          </div>
          <div className="hidden md:block">
            <div className="w-28 h-28 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm border-4 border-white/30">
              <User className="w-14 h-14 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-blue-500 hover:shadow-xl transition-all">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-slate-600">Announcements</CardTitle>
              <Bell className="w-5 h-5 text-blue-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">{announcements.length}</div>
            <p className="text-xs text-slate-500 mt-1">Unread messages</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-green-500 hover:shadow-xl transition-all">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-slate-600">Fees Paid</CardTitle>
              <CreditCard className="w-5 h-5 text-green-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-700">KES {totalPaid.toLocaleString()}</div>
            <p className="text-xs text-slate-500 mt-1">Total payments</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-purple-500 hover:shadow-xl transition-all">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-slate-600">Attendance</CardTitle>
              <Calendar className="w-5 h-5 text-purple-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-700">{attendanceRate}%</div>
            <p className="text-xs text-slate-500 mt-1">This term</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-orange-500 hover:shadow-xl transition-all">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-slate-600">Average Grade</CardTitle>
              <Award className="w-5 h-5 text-orange-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-700">B+</div>
            <p className="text-xs text-slate-500 mt-1">Current performance</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabbed Content */}
      <Tabs defaultValue="fees" className="space-y-6">
        <TabsList className="bg-slate-100">
          <TabsTrigger value="fees">Fee Payments</TabsTrigger>
          <TabsTrigger value="performance">Academic Performance</TabsTrigger>
          <TabsTrigger value="announcements">Announcements</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
        </TabsList>

        {/* Fee Payments Tab */}
        <TabsContent value="fees">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-6 h-6 text-green-500" />
                  Fee Payment Records
                </CardTitle>
                <Button onClick={generateFeeStatement} className="bg-green-600 hover:bg-green-700">
                  <Download className="w-4 h-4 mr-2" />
                  Download Statement
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Fee Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border-2 border-green-200">
                    <p className="text-sm text-slate-600 mb-2">Total Paid</p>
                    <p className="text-3xl font-bold text-green-700">KES {totalPaid.toLocaleString()}</p>
                  </div>
                  <div className="p-6 bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl border-2 border-orange-200">
                    <p className="text-sm text-slate-600 mb-2">Pending</p>
                    <p className="text-3xl font-bold text-orange-700">KES {pendingFees.toLocaleString()}</p>
                  </div>
                  <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl border-2 border-blue-200">
                    <p className="text-sm text-slate-600 mb-2">Balance</p>
                    <p className="text-3xl font-bold text-blue-700">KES 0</p>
                  </div>
                </div>

                {/* Payment History Table */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Payment History</h3>
                  {feePayments.length === 0 ? (
                    <div className="text-center py-12 text-slate-500">
                      <FileText className="w-16 h-16 mx-auto mb-4 text-slate-400" />
                      <p className="text-lg font-medium">No payment records</p>
                    </div>
                  ) : (
                    <div className="overflow-auto rounded-lg border border-slate-200">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-slate-50">
                            <TableHead>Date</TableHead>
                            <TableHead>Receipt No.</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Method</TableHead>
                            <TableHead>Purpose</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Action</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {feePayments.map((payment) => (
                            <TableRow key={payment.id}>
                              <TableCell>{new Date(payment.created_at).toLocaleDateString()}</TableCell>
                              <TableCell className="font-medium">{payment.receipt_number}</TableCell>
                              <TableCell className="font-bold text-green-700">KES {payment.amount.toLocaleString()}</TableCell>
                              <TableCell className="capitalize">{payment.payment_method?.replace('_', ' ')}</TableCell>
                              <TableCell className="capitalize">{payment.payment_type}</TableCell>
                              <TableCell>
                                <Badge className={payment.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                                  {payment.status}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Button variant="ghost" size="sm">
                                  <Download className="w-4 h-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Academic Performance Tab */}
        <TabsContent value="performance">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-6 h-6 text-purple-500" />
                  Academic Progress & Performance
                </CardTitle>
                <Button onClick={generateReportCard} className="bg-purple-600 hover:bg-purple-700">
                  <Download className="w-4 h-4 mr-2" />
                  Download Report Card
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Performance Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-6 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl border-2 border-purple-200">
                    <p className="text-sm text-slate-600 mb-2">Current Average</p>
                    <p className="text-4xl font-bold text-purple-700">B+</p>
                    <p className="text-xs text-slate-500 mt-2">78% - Good Performance</p>
                  </div>
                  <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl border-2 border-blue-200">
                    <p className="text-sm text-slate-600 mb-2">Class Rank</p>
                    <p className="text-4xl font-bold text-blue-700">5th</p>
                    <p className="text-xs text-slate-500 mt-2">Out of 40 students</p>
                  </div>
                  <div className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border-2 border-green-200">
                    <p className="text-sm text-slate-600 mb-2">Improvement</p>
                    <p className="text-4xl font-bold text-green-700">+5%</p>
                    <p className="text-xs text-slate-500 mt-2">From last term</p>
                  </div>
                </div>

                {/* Subject Performance */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Subject Performance</h3>
                  <div className="text-center py-12 text-slate-500">
                    <Award className="w-16 h-16 mx-auto mb-4 text-slate-400" />
                    <p className="text-lg font-medium">Results will be published soon</p>
                    <p className="text-sm mt-2">Check back after exams are marked</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Announcements Tab */}
        <TabsContent value="announcements">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-6 h-6 text-blue-500" />
                School Announcements
              </CardTitle>
            </CardHeader>
            <CardContent>
              {announcements.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <Bell className="w-16 h-16 mx-auto mb-4 text-slate-400" />
                  <p className="text-lg font-medium">No announcements</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {announcements.map((announcement) => (
                    <div key={announcement.id} className="p-5 border-2 border-slate-200 rounded-xl hover:border-blue-400 transition-all">
                      <div className="flex items-start justify-between mb-3">
                        <h3 className="font-semibold text-lg">{announcement.title}</h3>
                        <Badge className={announcement.priority === 'urgent' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}>
                          {announcement.priority}
                        </Badge>
                      </div>
                      <p className="text-slate-700 whitespace-pre-wrap">{announcement.content}</p>
                      <p className="text-xs text-slate-500 mt-3">{new Date(announcement.created_at).toLocaleDateString()}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Attendance Tab */}
        <TabsContent value="attendance">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-6 h-6 text-purple-500" />
                Attendance Records
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border-2 border-green-200">
                  <Calendar className="w-8 h-8 text-green-600 mb-3" />
                  <p className="text-sm text-slate-600 mb-2">Present Days</p>
                  <p className="text-3xl font-bold text-green-700">95</p>
                </div>
                <div className="p-6 bg-gradient-to-br from-red-50 to-rose-50 rounded-xl border-2 border-red-200">
                  <Calendar className="w-8 h-8 text-red-600 mb-3" />
                  <p className="text-sm text-slate-600 mb-2">Absent Days</p>
                  <p className="text-3xl font-bold text-red-700">3</p>
                </div>
                <div className="p-6 bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl border-2 border-orange-200">
                  <Calendar className="w-8 h-8 text-orange-600 mb-3" />
                  <p className="text-sm text-slate-600 mb-2">Late Arrivals</p>
                  <p className="text-3xl font-bold text-orange-700">2</p>
                </div>
                <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl border-2 border-blue-200">
                  <TrendingUp className="w-8 h-8 text-blue-600 mb-3" />
                  <p className="text-sm text-slate-600 mb-2">Attendance Rate</p>
                  <p className="text-3xl font-bold text-blue-700">{attendanceRate}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default StudentPortal;
